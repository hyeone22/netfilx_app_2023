import React from 'react'

function useDebounce() {
  return (
    <div>useDebounce</div>
  )
}

export default useDebounce